Proyecto Web Formula 1
Tecnologías: Node.js, MySQL, HTML, CSS, JS
Objetivo: Aplicación web completa con BD
Conclusión: Proyecto funcional y escalable
